package com.example.todo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
