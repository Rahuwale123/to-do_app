import 'package:hive/hive.dart';


class DatabaseHelper {
  static final _box = Hive.box('todoBox');

  static List getTodos() {
    return _box.values.toList();
  }
  static void addTodo(todo) {
    _box.add(todo);
  }
  static void updateTodo(int index,  todo) {
    _box.putAt(index, todo);
  }
  static void deleteTodo(int index) {
    _box.deleteAt(index);
  }
}