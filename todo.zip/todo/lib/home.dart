import 'package:flutter/material.dart';
import 'package:todo/database_helper.dart';
import 'package:todo/tolist.dart';

class home extends StatefulWidget {
  const home({super.key});

  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> {
  TextEditingController task = TextEditingController();
  List todo = [
    ['add you all tasks here',false]
  ];

  @override
  void initState() {
    super.initState();
    todo = DatabaseHelper.getTodos();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) {
              return AlertDialog(
                title: TextField(
                  controller: task,
                  decoration: InputDecoration(
                    labelText: 'Add new task',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                  ),
                ),
                content: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () {
                        setState(() {
                          todo.add([task.text, false]);
                          DatabaseHelper.addTodo([task.text, false]);
                          todo = DatabaseHelper.getTodos();
                        });
                        task.clear();
                        Navigator.pop(context);
                      },
                      child: Text("Save"),
                    ),
                    SizedBox(width: 30),
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text("Cancel"),
                    ),
                  ],
                ),
              );
            },
          );
        },
        child: Icon(Icons.add),
      ),
      backgroundColor: Color.fromARGB(255, 70, 108, 245),
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text("TO DO"),
        centerTitle: true,
        elevation: 0,
      ),
      body: ListView.builder(
        itemBuilder: (context, index) {
          return todolist(
            title: todo[index][0],
            checked: todo[index][1],
            ondelete: () {
              setState(() {
                todo.removeAt(index);
                DatabaseHelper.deleteTodo(index);
              });
            },
            onChanged: (value) {
              setState(() {
                todo[index][1] = !todo[index][1];
                DatabaseHelper.updateTodo(index, todo[index]);
              });
            },
          );
        },
        itemCount: todo.length,
      ),
    );
  }

}