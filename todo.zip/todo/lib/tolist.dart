import 'package:flutter/material.dart';
class todolist extends StatelessWidget {
final bool checked;
final String title;
final void Function(bool?)? onChanged;
final void Function()? ondelete;
   todolist({super.key, required this.title, required this.checked, this.onChanged, this.ondelete});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all( 12.0),
      child: Container(
        color: Colors.amber,
        height: 50,
        width: double.infinity,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Checkbox(
                  value: checked, 
                  onChanged:onChanged),
                Center(child: Text(title))
              ],
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4.0,horizontal: 13),
              child: Container(
                height: 40,
                width: 30,
                child: IconButton(onPressed: ondelete,
                iconSize: 30,
                 icon: Icon(Icons.delete)),
              ),
            )
          ],
        ),
      ),
    );
  }
}